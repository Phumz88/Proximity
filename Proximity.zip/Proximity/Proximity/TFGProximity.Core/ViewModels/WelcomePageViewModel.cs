﻿using Prism.Mvvm;

namespace TFGProximity.Core.ViewModels
{
	public class WelcomePageViewModel : BindableBase
	{
		public WelcomePageViewModel ()
		{

		}
	}
}
