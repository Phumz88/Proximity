﻿using System;

namespace TFGProximity.Core.Enums
{
	//[Flags]
	public enum BeaconRoleEnum
	{
		Unknown = 0,
		Sentinel = 1,
		Entry = 2,
		Proximity = 3
	}
}
