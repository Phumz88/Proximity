﻿using System;
using Prism.Events;

namespace TFGProximity.Core.Helpers
{
	public class IsBusyEvent : PubSubEvent<bool>
	{
	}
}
