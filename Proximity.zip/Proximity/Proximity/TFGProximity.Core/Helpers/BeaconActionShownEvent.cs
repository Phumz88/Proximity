﻿using Prism.Events;

namespace TFGProximity.Core.Helpers
{
	public class BeaconActionShownEvent : PubSubEvent<bool>
	{
	}
}
