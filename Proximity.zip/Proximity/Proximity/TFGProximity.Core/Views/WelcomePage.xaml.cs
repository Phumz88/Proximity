﻿using Xamarin.Forms;

namespace TFGProximity.Core.Views
{
	public partial class WelcomePage : ContentPage
	{
		public WelcomePage ()
		{
			InitializeComponent ();
		}
	}
}

