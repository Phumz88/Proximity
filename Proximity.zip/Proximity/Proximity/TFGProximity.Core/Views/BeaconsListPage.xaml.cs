﻿using Xamarin.Forms;

namespace TFGProximity.Core.Views
{
	public partial class BeaconsListPage : ContentPage
	{
		public BeaconsListPage()
		{
			InitializeComponent();
		}
	}
}

